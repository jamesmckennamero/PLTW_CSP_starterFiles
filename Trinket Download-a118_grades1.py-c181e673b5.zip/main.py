#   a118_grades.py
#   This code is incomplete. 
my_courses = ["English", "Math", "CS"]

