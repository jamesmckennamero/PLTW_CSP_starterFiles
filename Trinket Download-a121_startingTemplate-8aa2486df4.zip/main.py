# a121_catch_a_turtle.py
#-----import statements-----


#-----game configuration----


#-----initialize turtle-----


#-----game functions--------


#-----events----------------